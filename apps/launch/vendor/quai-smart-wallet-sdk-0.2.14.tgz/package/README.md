# Wallet host SDK

Private integration package for Quai Smart Wallet. The connector and upstream Safe
helpers are also available in the `quais/smart-account` review branch; that source has not yet been
published as a quais release. Privy, relay policies and token catalogs stay outside
quais.js.

See [integration](../../docs/INTEGRATION.md) and [contract specification](../../docs/WALLET_SPEC.md).
Build with `npm run build --prefix packages/sdk`.

`safeRequest` and `encodeSafeExecute` use upstream SafeTx. `findSafe` and
`encodeSafeCreate` use the selected factory profile and canonical single-owner setup.
Verify the deployment and account with `verifySafeDeployment` and `verifySafeAccount`.
`safeMessageRequest` supplies CompatibilityFallbackHandler wrapping for ERC-1271.

`signOwnerRequest` explicitly uses Safe's personal-sign mode for SafeTx/SafeMessage,
with decoded host review and local owner verification. Safe signatures do not expire
on-chain. The host's review TTL is not a contract deadline.

`PrivyOwnerAdapter` remains optional. The SDK never takes a Privy app secret, derives
an owner key from a signature, or exposes private keys to dApps. Every request must
survive selected-account and connection-lifecycle checks before submission.

## In-page clients (0.2.0)

`@quai-smart-wallet/sdk/core` contains the same `QuaiWalletController` used by the
standalone browser and Privy frontends, including verified deployment discovery,
Safe call decoding, paid fee review, transaction submission and deposit recovery.
The old app module paths are re-exports, not second implementations. The small
`/connector` entry remains independent of Privy and the controller.

`InPageWalletTransport` adapts that controller to `SmartAccountClient`. The host
provides signer selection and an explicit review UI; the SDK continues to verify
owner/account identity and signed fee bounds. Use the existing Privy application
with approved origins (and an optional separate app client), not a new application. Pin the previously connected
Safe with `expectedAccount` when restoring an existing app session.

Pending relay activity belongs to the owner and survives origin changes. Request
IDs and Safe transaction hashes are stored before submission, and same-origin
requests use Web Locks. A missing record from the former wallet origin is not
proof that a transaction stopped. Keep its uncertainty and check standalone
wallet activity; do not silently resend it. Source-chain deposit history remains
origin-local and must be checked on the original wallet site when relevant.

Run `npm run pack:sdk -- /path/to/quainance/vendor` from the repository root to
produce the versioned npm archive for Quainance. The script verifies the packaged
mainnet manifest matches the reviewed relay manifest. The Quainance lockfile pins
the archive's integrity; after changes, rebuild the archive and refresh that one
lock entry. No registry credentials or secret files are included. Package publishing can replace the archive dependency later.

SDK 0.2.1 includes token identities on connector swap review facts and routes.

SDK 0.2.2 supports paying a verified USDT → native QUAI swap's fee from its
output, with no existing QUAI balance. The relay must return a matching
`funding.source: "swap-output"` quote. The client independently decodes the
canonical batch and checks that its minimum output exceeds the maximum fee.
Reviews show the net minimum and require explicit approval for this funding mode.
This requires the matching relay release; older relays fail closed.
In-page reviews also expose the verified fee quote for a host-owned review
preference; every submission retains owner signing and relay validation.


SDK 0.2.6 reduces pre-signature network work. Connected `getAccount` reads reuse
initialized identity while checking the current signer and expected Safe. Every
action still refreshes the verified account, balance and relay policy, including
again just before signature. Discovery performs one complete Safe verification;
deployment code hashes and independent quote/balance/nonce reads run in parallel.
No fee, balance or ownership result is cached across transaction validations.
